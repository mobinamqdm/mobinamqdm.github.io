clc;
clear;
t = 0:0.01:10;
n1 = 10;
d1 = [1, 5, 11, 15, 0];
s1 = tf(n1, d1);
figure;
bode(s1);
margin(s1);
grid;

n2 = [8379, 300];
d2 = [838.15, 4191.75, 9224.65, 12583.25, 15, 0];
figure;
s2 = tf(n2, d2);
bode(s2);
margin(s2);
grid;
