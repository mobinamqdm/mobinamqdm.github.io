clc;
clear;
t = 0:0.1:10;
s = tf('s');
c = s * (s + 1) * (s + 10);
g = 200 / c;
b1 = 0.017 * (1.71 * s + 1);
b2 = 0.0716 * (1.79 * s + 1);
l1 = g * b1;

bode(g);
margin(g);
grid;

l2 = b2 * g;

figure;
bode(l1);
margin(l1);
grid;

figure;
bode(l2);
margin(l2);
grid;

t1_res = l1 / (l1 + 1);
y1 = step(t1_res, t);

t2_res = l2 / (l2 + 1);
y2 = step(t2_res, t);

figure;
plot(t, y1);
grid;

figure;
plot(t, y2);
grid;
