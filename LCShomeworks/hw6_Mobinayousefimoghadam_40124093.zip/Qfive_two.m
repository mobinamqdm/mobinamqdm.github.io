clc;
clear;
t = 0:0.1:10;
s = tf('s');
c = s * (s + 1) * (s + 10);
g = 200 / c;
b2 = (0.1 * s + 0.05);
b3 = (0.5 * s + 0.05);
l2 = g * b3;
l3 = g * b2;

bode(g);
margin(g);

figure;
bode(l2);
margin(l2);

figure;
bode(l3);
margin(l3);
