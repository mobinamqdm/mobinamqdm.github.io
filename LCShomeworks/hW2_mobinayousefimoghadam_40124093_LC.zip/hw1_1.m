t_vals = linspace(0, 2.5, 25001); 
omega_n = 11.1499;
omega_sq = omega_n^2;
damping_ratio = 0.2509;
gain = 1.58;

numerator_closed = gain * omega_sq;
denominator_closed = [1, 2 * omega_n * damping_ratio, omega_sq];
sys_closed = tf(numerator_closed, denominator_closed);
response_closed = step(sys_closed, t_vals);

numerator_open = gain * omega_sq;
denominator_open = [1, 2 * damping_ratio * omega_n, (1 - gain) * omega_sq];
sys_open = tf(numerator_open, denominator_open);
response_open = step(sys_open, t_vals);

figure;
plot(t_vals, response_closed, "Color", 'green', 'LineWidth', 2); % تغییر رنگ به قرمز روشن‌تر
ylabel("Amplitude", "FontSize", 13, "FontWeight", "bold");
xlabel("Time (s)", "FontSize", 13, "FontWeight", "bold");
title("Step Response - Closed Loop", "FontSize", 15, "FontWeight", "bold");
grid on;

figure;
plot(t_vals, response_open, "Color", 'red', 'LineWidth', 2); % تغییر رنگ به آبی تیره‌تر
ylabel("Amplitude", "FontSize", 13, "FontWeight", "bold");
xlabel("Time (s)", "FontSize", 13, "FontWeight", "bold");
title("Step Response - Open Loop", "FontSize", 15, "FontWeight", "bold");
grid on;
