time_vector = linspace(0, 10, 100001); 
numerator1 = 0.4;
denominator1 = [1, 0.8];
system_closed = tf(numerator1, denominator1);
response_closed = step(system_closed, time_vector);
figure;
plot(time_vector, response_closed, 'Color', 'blue', 'LineWidth', 1.7); % رنگ cyan
grid on;
xlabel("Time (s)", 'FontSize', 13, 'FontWeight', 'bold');
ylabel("Amplitude", 'FontSize', 13, 'FontWeight', 'bold');
title("Step Response - Closed Loop System", 'FontSize', 14, 'FontWeight', 'bold');
numerator2 = 0.4;
denominator2 = [1, 0.4];
system_open = tf(numerator2, denominator2);
response_open = step(system_open, time_vector);
figure;
plot(time_vector, response_open, 'Color','magenta', 'LineWidth', 1.7); % رنگ blue
grid on;
xlabel("Time (s)", 'FontSize', 13, 'FontWeight', 'bold');
ylabel("Amplitude", 'FontSize', 13, 'FontWeight', 'bold');
title("Step Response - Open Loop System", 'FontSize', 14, 'FontWeight', 'bold');
